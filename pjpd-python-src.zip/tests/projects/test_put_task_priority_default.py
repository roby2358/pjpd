"""
Tests for pjpd_put_task priority handling: creating without a priority
defaults to 50, updating without a priority preserves the existing one.
"""

import pytest

from src.mcp_wrapper import pjpd_put_task
from src.projects.projects import Projects


class TestPutTaskPriorityDefault:
    @pytest.fixture
    def projects_manager(self, tmp_path, monkeypatch):
        """Create a Projects manager rooted at tmp_path and patch the wrapper to use it."""
        manager = Projects(tmp_path)
        monkeypatch.setattr("src.mcp_wrapper.projects_manager", manager)
        return manager

    @pytest.mark.asyncio
    async def test_create_without_priority_defaults_to_50(self, projects_manager):
        response = await pjpd_put_task(description="default priority", tag="defp")

        assert response["success"] is True
        assert response["result"]["priority"] == 50

    @pytest.mark.asyncio
    async def test_create_with_priority_uses_it(self, projects_manager):
        response = await pjpd_put_task(description="explicit", tag="expl", priority=7)

        assert response["success"] is True
        assert response["result"]["priority"] == 7

    @pytest.mark.asyncio
    async def test_update_without_priority_preserves_existing(self, projects_manager):
        task = projects_manager.add_task("keep my priority", 33, "keep")

        response = await pjpd_put_task(
            description="new words, same priority", id=task.id
        )

        assert response["success"] is True
        assert response["result"]["priority"] == 33
        assert response["result"]["description"] == "new words, same priority"

        reloaded = projects_manager.project.get_task(task.id)
        assert reloaded.priority == 33

    @pytest.mark.asyncio
    async def test_update_with_priority_changes_it(self, projects_manager):
        task = projects_manager.add_task("change me", 33, "chg")

        response = await pjpd_put_task(
            description="changed", id=task.id, priority=90
        )

        assert response["success"] is True
        assert response["result"]["priority"] == 90
